package com.alkewallet.billetera;
public interface IMoneda {

public String getNombre();
public Double getValor();
public String getSimbol();
public String getPluralName();

}
